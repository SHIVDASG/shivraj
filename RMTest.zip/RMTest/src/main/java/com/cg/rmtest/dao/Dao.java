package com.cg.rmtest.dao;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;
import com.cg.rmtest.model.AutoPayment;
import com.cg.rmtest.model.Beneficiary;
import com.cg.rmtest.model.CreditCard;
import com.cg.rmtest.model.CustomerBean;

public class Dao {
	private EntityManagerFactory factory = Persistence.createEntityManagerFactory("RMTSTEE");
	private EntityManager manager = factory.createEntityManager();
	private EntityTransaction transaction = manager.getTransaction();

	public void copyDetails(BigInteger uci, Beneficiary beneficiary) {
		transaction.begin();
		CustomerBean customer = manager.find(CustomerBean.class, uci);
		//Beneficiary beneficiary2 = manager.find(Beneficiary.class, beneficiary.getAccountNumber());
		beneficiary.setCustomer(customer);
		manager.persist(beneficiary);
		transaction.commit();
	}

	public Beneficiary getBeneficiary(BigInteger accountNumber) {// returns beneficiary
		// object
		Beneficiary beneficiary = manager.find(Beneficiary.class, accountNumber);

		return beneficiary;

	}

	public boolean deleteDetails(BigInteger accountNumber) {
		boolean check = false;
		Beneficiary beneficiary = manager.find(Beneficiary.class, accountNumber);
		transaction.begin();
		manager.remove(beneficiary);
		transaction.commit();
		check = true;
		return check;

	}

	public Set<Beneficiary> getDetails(String uci) {// returns set of beneficiaries for a given uci
		CriteriaQuery<Beneficiary> query = manager.getCriteriaBuilder().createQuery(Beneficiary.class);
		Root<Beneficiary> benificiaryRoot = query.from(Beneficiary.class);

		query.select(benificiaryRoot);

		TypedQuery<Beneficiary> query2 = manager.createQuery(query);
		return new HashSet<Beneficiary>(query2.getResultList());

	}

	public void CopyAutoPayment(AutoPayment autoPayment) {
		transaction.begin();
		manager.persist(autoPayment);
		transaction.commit();
	}
	
	public void getRequests() {
		Set<BigInteger> ucis = new HashSet<>();
		CriteriaBuilder builder=manager.getCriteriaBuilder();
		CriteriaQuery<BigInteger> query = builder.createQuery(BigInteger.class);
		Root<CustomerBean> custRoot= query.from(CustomerBean.class);
		Join<CustomerBean, CreditCard> creditCards = custRoot.join("creditCards");
		query.select(custRoot.<BigInteger>get("uci")).where(builder.equal(creditCards.get("status"), "PENDING"));
		System.out.println(manager.createQuery(query).getResultList());
	}

	public Set<BigInteger> getCardDetails(BigInteger uci) {
//		CriteriaBuilder builder = manager.getCriteriaBuilder();
//		CriteriaQuery<BigInteger> query = builder.createQuery(BigInteger.class);
//		Root<CustomerBean> custRoot = query.from(CustomerBean.class);
//		Join<CustomerBean, CreditCard> creditCards = custRoot.join("creditCards");
//		query.select(creditCards.<BigInteger>get("cardNumber")).where(
//				builder.and(builder.equal(custRoot.get("uci"), uci)));
//		return new HashSet<>(manager.createQuery(query).getResultList());// must include WHERE
		Set<BigInteger> ucis = new HashSet<>();
		CriteriaBuilder builder=manager.getCriteriaBuilder();
		CriteriaQuery<BigInteger> query = builder.createQuery(BigInteger.class);
//		Root<CustomerBean> custRoot= query.from(CustomerBean.class);
//		Join<CustomerBean, CreditCard> creditCards = custRoot.join("creditCards");
		Root<CreditCard> creditCard = query.from(CreditCard.class);
		Join<CreditCard, CustomerBean> Customer = creditCard.join("customer");
		query.select(Customer.<BigInteger>get("uci")).where(builder.equal(creditCard.get("cardStatus"), "asdasd"));
		return new HashSet<BigInteger>(manager.createQuery(query).getResultList());
	}

}

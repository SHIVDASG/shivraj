package com.cg.rmtest.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Autopayment_table")
public class AutoPayment implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4643315123018156703L;
	@EmbeddedId
	private ServiceProviderId serviceProviderId;
	private BigDecimal amount;
	private String dateOfStart;

	public AutoPayment() {
		super();
	}

	public AutoPayment(ServiceProviderId serviceProviderId, BigDecimal amount, String dateOfStart) {
		super();
		this.serviceProviderId = serviceProviderId;
		this.amount = amount;
		this.dateOfStart = dateOfStart;
	}

	@Override
	public String toString() {
		return "AutoPayment [serviceProviderId=" + serviceProviderId + ", amount=" + amount + ", dateOfStart="
				+ dateOfStart + "]";
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getDateOfStart() {
		return dateOfStart;
	}

	public void setDateOfStart(String dateOfStart) {
		this.dateOfStart = dateOfStart;
	}

	public ServiceProviderId getServiceProviderId() {
		return serviceProviderId;
	}

	public void setServiceProviderId(ServiceProviderId serviceProviderId) {
		this.serviceProviderId = serviceProviderId;
	}

}

package com.cg.rmtest.ui;

import java.math.BigInteger;

import com.cg.rmtest.dao.Dao;
import com.cg.rmtest.model.AutoPayment;
import com.cg.rmtest.model.Beneficiary;

public class Main {

	public static void main(String[] args) {
		Beneficiary beneficiary = new Beneficiary();
		AutoPayment autoPayment = new AutoPayment();
		Dao dao = new Dao();
		beneficiary.setAccountName("ayushhandsome");
		beneficiary.setAccountNumber(new BigInteger("9999776666886685"));
		beneficiary.setBankName("HDFC");
		beneficiary.setIfscCode("hdfc1234567");
		beneficiary.setStatus(Status.APPROVED);
		beneficiary.setType(Type.OTHERSINSAME);
		//autoPayment.setAmount(new BigDecimal(100));
		//autoPayment.setServiceProviderId(new ServiceProviderId(new BigInteger("100"), new BigInteger("123456789")));
		//autoPayment.setDateOfStart("12-Dec, 2020");
		//System.out.println(dao.getBeneficiary(new BigInteger("9999996655887745")));
		//dao.deleteDetails(new BigInteger("9999996655887745"));
	//	System.out.println(dao.getBeneficiary(new BigInteger("9999996655887745")));
		dao.copyDetails(new BigInteger("123456"), beneficiary);
		//dao.CopyAutoPayment(autoPayment);
		System.out.println(dao.getCardDetails(new BigInteger("123456")));
	}

}

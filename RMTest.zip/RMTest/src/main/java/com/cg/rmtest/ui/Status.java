package com.cg.rmtest.ui;

public enum Status {
		APPROVED, DECLINED, PENDING
}

package com.cg.rmtest.ui;

public enum Type {
	SELFINSAME, SELFINOTHERS, OTHERSINSAME, OTHERSINOTHERS
}



//creditcard expiry date
//exceptions not working

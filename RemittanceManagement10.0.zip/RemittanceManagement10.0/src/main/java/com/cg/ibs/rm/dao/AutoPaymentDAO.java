package com.cg.ibs.rm.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Set;
import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.ServiceProvider;
import com.cg.ibs.rm.exception.IBSExceptions;

public interface AutoPaymentDAO {
	public Set<ServiceProvider> showServiceProviderList();

	public Set<AutoPayment> getAutopaymentDetails(BigInteger uci);

	public boolean copyDetails(BigInteger uci, AutoPayment autoPayment) throws IBSExceptions;

	public boolean deleteDetails(BigInteger uci, BigInteger serviceProviderId) throws IBSExceptions;

	public BigDecimal getCurrentBalance(BigInteger accountNumber) throws IBSExceptions;

	public boolean setCurrentBalance(BigDecimal currentBalnce, BigInteger accountNumber);

}
package com.cg.ibs.rm.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.regex.Pattern;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;

import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.ServiceProvider;
import com.cg.ibs.rm.dao.AutoPaymentDAO;
import com.cg.ibs.rm.dao.AutoPaymentDAOImpl;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.util.JpaUtil;

public class AutoPaymentServiceImpl implements AutoPaymentService {
	private AutoPaymentDAO autoPaymentDao = new AutoPaymentDAOImpl();
	private static final Logger LOGGER = Logger.getLogger(AutoPaymentServiceImpl.class.getName());

	@Override
	public Set<AutoPayment> showAutopaymentDetails(BigInteger uci) {
		LOGGER.info("entered showAutopaymentDetails in autopaymentservimpl");
		return autoPaymentDao.getAutopaymentDetails(uci);

	}

	@Override
	public Set<ServiceProvider> showIBSServiceProviders() {
		LOGGER.info("entered  showIBSServiceProviders in autopaymentservimpl");
		return autoPaymentDao.showServiceProviderList();

	}

	@Override
	public boolean autoDeduction(BigInteger accountNumber, AutoPayment autoPayment) throws IBSExceptions {
		LOGGER.info("entered  autodeduction in autopaymentservimpl");
		EntityTransaction transaction = JpaUtil.getTransaction();
		LocalDate today = LocalDate.now();
		boolean validAutoDeduct = false;
		LOGGER.debug(autoPaymentDao.getCurrentBalance(accountNumber));
		if (Pattern.matches("^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$", autoPayment.getDateOfStart())) {
			DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate startOfAutoPayment = LocalDate.parse(autoPayment.getDateOfStart(), dtFormatter);
			if (!startOfAutoPayment.isBefore(today)) {
				transaction.begin();
				autoPaymentDao.copyDetails(accountNumber, autoPayment);
				transaction.commit();
				if (today.equals(startOfAutoPayment)) {
					if (-1 != autoPaymentDao.getCurrentBalance(accountNumber).compareTo(autoPayment.getAmount())) {
						BigDecimal balance = autoPaymentDao.getCurrentBalance(accountNumber)
								.subtract(autoPayment.getAmount());
						autoPaymentDao.setCurrentBalance(balance, accountNumber);
						startOfAutoPayment.plusMonths(1);
						LOGGER.debug(autoPaymentDao.getCurrentBalance(accountNumber));
					}
				}
				validAutoDeduct = true;

			}
		}
		return validAutoDeduct;
	}

	@Override
	public boolean updateRequirements(BigInteger uci, BigInteger spi) throws IBSExceptions {
		boolean result = false;
		LOGGER.info("entered updateRequirements in autopaymentservimpl");
		EntityTransaction transaction = JpaUtil.getTransaction();
		transaction.begin();
		result = autoPaymentDao.deleteDetails(uci, spi);
		transaction.commit();
		return result;
	}

}
package com.cg.ibs.rm.service;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.dao.BeneficiaryDAO;
import com.cg.ibs.rm.dao.BeneficiaryDAOImpl;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.ui.Status;
import com.cg.ibs.rm.util.JpaUtil;

public class BeneficiaryAccountServiceImpl implements BeneficiaryAccountService {
	private static Logger logger = Logger.getLogger(BeneficiaryAccountServiceImpl.class);
	private BeneficiaryDAO beneficiaryDao = new BeneficiaryDAOImpl();

	@Override
	public Set<Beneficiary> showBeneficiaryAccount(BigInteger uci) {
		logger.info("entering into showBeneficiaryAccount method of BeneficiaryAccountServiceImpl class");
		return new HashSet<>(beneficiaryDao.getDetails(uci));

	}

	@Override
	public boolean validateBeneficiaryAccountNumber(String accountNumber) {
		logger.info("entering into validateBeneficiaryAccountNumber method of BeneficiaryAccountServiceImpl class");
		boolean validNumber = false;
		if (Pattern.matches("^[0-9]{11}$", accountNumber)) {
			validNumber = true;
		}
		return validNumber;
	}

	@Override
	public boolean validateBeneficiaryAccountNameOrBankName(String name) {
		logger.info(
				"entering into validateBeneficiaryAccountNameOrBankName method of BeneficiaryAccountServiceImpl class");
		boolean validName = false;
		if (Pattern.matches("^[a-zA-Z]*$", name) && (null != name))
			validName = true;
		return validName;
	}

	@Override
	public boolean validateBeneficiaryIfscCode(String ifsc) {
		logger.info("entering into validateBeneficiaryIfscCode method of BeneficiaryAccountServiceImpl class");
		boolean validIfsc = false;
		if (ifsc.length() == 11)
			validIfsc = true;
		return validIfsc;
	}

	@Override
	public boolean modifyBeneficiaryAccountDetails(BigInteger accountNumber, Beneficiary beneficiary1)
			throws IBSExceptions {
		Beneficiary beneficiary;
		boolean validModify = false;
		logger.info("entering into modifyBeneficiaryAccountDetails method of BeneficiaryAccountServiceImpl class");
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		entityTransaction.begin();
		beneficiary = beneficiaryDao.getBeneficiary(accountNumber);
		logger.debug(beneficiary1);
		if (beneficiary1.getAccountName() != null) {
			beneficiary.setAccountName(beneficiary1.getAccountName());
		}
		if (beneficiary1.getIfscCode() != null) {
			beneficiary.setIfscCode(beneficiary1.getIfscCode());
		}
		if (beneficiary1.getBankName() != null) {
			beneficiary.setBankName(beneficiary1.getBankName());
		}
		beneficiary.setStatus(Status.PENDING);
		if (beneficiaryDao.updateDetails(beneficiary)) {
			validModify = true;
		}
		entityTransaction.commit();
		logger.debug(beneficiary1);
		return validModify;
	}

	@Override
	public boolean deleteBeneficiaryAccountDetails(BigInteger accountNumber) throws IBSExceptions {
		logger.info("entering into deleteBeneficiaryAccountDetails method of BeneficiaryAccountServiceImpl class");
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		entityTransaction.begin();
		boolean result = beneficiaryDao.deleteDetails(accountNumber);
		entityTransaction.commit();
		return result;
	}

	@Override
	public boolean saveBeneficiaryAccountDetails(BigInteger uci, Beneficiary beneficiary) throws IBSExceptions {
		boolean check = false;
		logger.info("entering into saveBeneficiaryAccountDetails method of BeneficiaryAccountServiceImpl class");
		EntityTransaction entityTransaction = JpaUtil.getTransaction();
		entityTransaction.begin();
		beneficiary.setStatus(Status.PENDING);
		if (beneficiaryDao.copyDetails(uci, beneficiary)) {
			check = true;
		}
		entityTransaction.commit();
		return check;
	}


	

}
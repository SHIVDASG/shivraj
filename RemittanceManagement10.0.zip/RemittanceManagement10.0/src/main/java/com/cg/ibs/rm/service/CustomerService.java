package com.cg.ibs.rm.service;

import java.math.BigInteger;

import com.cg.ibs.rm.dao.CustomerDAO;
import com.cg.ibs.rm.exception.IBSExceptions;

public class CustomerService {
	CustomerDAO customerDAO=new CustomerDAO();
	public String returnName(BigInteger uci)
	{
		return customerDAO.returnName(uci);
	}
	
	public boolean checkUciList(BigInteger uci) {//check whether uci is present or not
		boolean checkUci = false;
		if (customerDAO.getUciList().contains(uci)) {
			checkUci = true;
		}
		return checkUci;
	}
}
